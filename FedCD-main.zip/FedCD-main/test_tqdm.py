import time

import tqdm

for i in tqdm(range(100)):
    time.sleep(0.1)